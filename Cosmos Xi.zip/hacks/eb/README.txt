A Pen created at CodePen.io. You can find this one at https://codepen.io/bennettfeely/pen/LKjmA.

 Collection of some fresh, flat toggles. All utilize the "checkbox" hack. See: http://css-tricks.com/the-checkbox-hack/

Which # do you like best?