var paragraph = {
  "loadFile": [
    {
      name:"loadFile1",
      addons: [{
        name:"process",
        type:"point",
        timer: 2000,
        number: 100
      }]
    },
    "loadFile2",
    "loadFile3"
  ],
  "getMap": [
    {
      name: "getMap1",
      timer: 5000
    },
    "getMap2",
    "getMap3",
    "getMap4",
    "getMap5",
    "getMap6"
  ]
};
