Coffee-shop-fake-hacker

Run this app in your local wifi hangout and pretend
you're hacking.
