# Fallout Terminal Hacker

- a tool to help crack terminal passwords in Fallout 4
- open index.html in the browser and follow instructions
