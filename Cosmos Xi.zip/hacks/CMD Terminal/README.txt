A Pen created at CodePen.io. You can find this one at https://codepen.io/johnchinjew/pen/JYWYXq.

 One neat-o hacking terminal where you can pretend to hack into the mainframe!  (inspired by hackertyper.net)