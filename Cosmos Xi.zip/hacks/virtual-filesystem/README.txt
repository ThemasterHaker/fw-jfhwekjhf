A Pen created at CodePen.io. You can find this one at https://codepen.io/arnellebalane/pen/oWPQmJ.

 Virtual filesystem with a working Finder, Terminal, and TextEdit applications.