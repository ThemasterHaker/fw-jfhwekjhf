A Pen created at CodePen.io. You can find this one at https://codepen.io/AndrewBarfield/pen/qEqWMq.

 A console for the Web written completely in JavaScript. The console supports Web versions of Linux commands.