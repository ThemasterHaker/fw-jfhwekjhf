# ChatBot
A Simple ChatBot Widget

![forthebadge](https://forthebadge.com/images/badges/built-with-love.svg)
![a](https://forthebadge.com/images/badges/uses-css.svg)
![a](https://forthebadge.com/images/badges/uses-html.svg)
![a](https://forthebadge.com/images/badges/uses-js.svg)
![forthebadge](https://forthebadge.com/images/badges/built-with-swag.svg)
![forthebadge](https://forthebadge.com/images/badges/60-percent-of-the-time-works-every-time.svg)
![forthebadge](https://forthebadge.com/images/badges/kinda-sfw.svg)
![a](https://forthebadge.com/images/badges/makes-people-smile.svg)


Check out the [Demo](http://ashwinshenoy.com/chatbot/)

Kindly create an api.ai account and train the bot and integrate it in js/script.js file by using api.ai client key.

Also based on getting the required fields (like name, email) , you can call your json backend to send email/integrate in slack etc.
Parameter to check if all fields are entered is actionIncomplete.(I have written comments in the JS file)

You can use webhooks directly from api.ai or call json api from js file based on actionIncomplete parameter = false.

Also this ChatBot is built in the form of widget, every logic happens in js file including dynamic html content addition.
You also could put the html content in index.html.

Remember to change the api.ai key in js/script.js file

There can be mistakes in the code :P

Do Let me know your thoughts on this :)
!
