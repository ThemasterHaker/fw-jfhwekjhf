A Pen created at CodePen.io. You can find this one at https://codepen.io/dudleystorey/pen/zqgGn.

 Heavily styled button element that uses flexbox for alignment, transitions for visual behaviour and Web Audio API for triggered sound. [A full explanatory blog article](http://thenewcode.com/885/A-Big-Red-Party-Button-with-the-Web-Audio-API)